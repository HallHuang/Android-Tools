

/**
 * desc   : SpannableString,话题等处理
 * 参考：https://blog.csdn.net/u014620028/article/details/78394157
 * version: 1.0
 */
public class TextContentUtil {

    private static final String AT = "@[\\w\\p{InCJKUnifiedIdeographs}-]{1,26}";
    private static final String TOPIC = "#[\\p{Print}\\p{InCJKUnifiedIdeographs}&&[^#]]+#";
    private static final String URL = "http[s]{0,1}://[a-zA-Z0-9+&@#/%?=~_\\-|!:,\\.;]*[a-zA-Z0-9+&@#/%=~_|]";
    private static final String URL_STR = "点击查看链接>>";

    private static final String ALL = "(" + AT + ")" + "|" + "(" + TOPIC + ")" + "|" + "(" + URL_STR + ")";

    public static SpannableStringBuilder getFeedText(String str, final TextView textView) {
        String content = str;

        // 处理匹配的url
        List<String> urls = new ArrayList<>();
        int urlIndex = 0;
        Pattern p = Pattern.compile(URL);
        Matcher m = p.matcher(content);
        while (m.find()) {
            String urlStr = m.group();
            if (urlStr.contains("http://") || urlStr.contains("https://")) {
                //如果末尾有英文逗号或者中文逗号等，就去掉
                while (urlStr.endsWith(",") || urlStr.endsWith("，") || urlStr.endsWith(".") || urlStr.endsWith("。") || urlStr.endsWith(";") || urlStr.endsWith("；") || urlStr.endsWith("！") || urlStr.endsWith("!") || urlStr.endsWith("?") || urlStr.endsWith("？")) {
                    urlStr = urlStr.substring(0, urlStr.length() - 1);
                }
                urls.add(urlStr);
                content = content.replace(urlStr, URL_STR);
            }
        }

        // 处理开始
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(content);
        // 设置正则
        Pattern pattern = Pattern.compile(ALL);
        Matcher matcher = pattern.matcher(spannableStringBuilder);

        if (matcher.find()) {
            if (!(textView instanceof EditText)) {
                //class ClickableMovementMethod extends LinkMovementMethod
                textView.setMovementMethod(ClickableMovementMethod.getInstance()); //激活链接
                textView.setFocusable(false);
                textView.setClickable(false);
                textView.setLongClickable(false);
            }
            matcher.reset();
        }

        while (matcher.find()) {
            final String at = matcher.group(1);
            final String topic = matcher.group(2);
            final String url = matcher.group(3);

            // 处理@
            if (at != null) {
                int start = matcher.start(1);
                int end = start + at.length();

                //class NoLineClickableSpan extends ClickableSpan
                NoLineClickableSpan myClickableSpan = new NoLineClickableSpan(textView.getContext()) {
                    @Override
                    public void onClick(View widget) {
                        Intent intent = new Intent(textView.getContext(), UserActivity.class);
                        String username = at.substring(1);  //public String substring(int beginIndex)
                        intent.putExtra(Constants.PASSED_USER_NAME, username);
                        textView.getContext().startActivity(intent);
                    }
                };
                spannableStringBuilder.setSpan(myClickableSpan, start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            }

            // 处理##
            if (topic != null) {
                int start = matcher.start(2);
                int end = start + topic.length();
                NoLineClickableSpan clickableSpan = new NoLineClickableSpan(textView.getContext()) {
                    @Override
                    public void onClick(View widget) {
                        Toast.makeText(textView.getContext(), "点击了话题：" + topic, Toast.LENGTH_LONG).show();
                    }
                };
                spannableStringBuilder.setSpan(clickableSpan, start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            }

            // 处理url
            if (url != null) {
                int start = matcher.start(3);
                int end = start + url.length();
                // 多链接处理
                final String urlPath = urls.get(urlIndex);
                urlIndex++;
                NoLineClickableSpan clickableSpan = new NoLineClickableSpan(textView.getContext()) {
                    @Override
                    public void onClick(View widget) {
                        //Intent.ACTION_VIEW: 根据数据类型打开相应的活动
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlPath));
                        textView.getContext().startActivity(browserIntent);
                    }
                };
                // 图片替换链接，暂不设置
                Drawable drawable = textView.getContext().getResources().getDrawable(R.drawable.ic_accessory);
                drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
                //class ClickableImageSpan extends ImageSpan
                ClickableImageSpan imageSpan = new ClickableImageSpan(drawable, ImageSpan.ALIGN_BOTTOM) {
                    @Override
                    public void onClick(View widget) {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlPath));
                        textView.getContext().startActivity(browserIntent);
                    }
                };
                spannableStringBuilder.setSpan(imageSpan, start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE);
            }
        }
        return spannableStringBuilder;
    }
}
