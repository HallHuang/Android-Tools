package me.iwf.photopicker.utils;

import androidx.core.content.FileProvider;

/**
 * Created by Donglu on 2017/6/7.
 */

public class PhotoFileProvider extends FileProvider {
}
